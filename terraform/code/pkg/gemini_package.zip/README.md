Script to SSH to linux servers from Lambda using RSA Keys.

To use the script you have to:

1) update variables inside lambda_function.py
2) create file lambda_kp.pem with your rsa pem key
3) update the command to what you need
