import json
import paramiko
import sys
import boto3
import botocore
import tempfile
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client('s3')

def lambda_handler(event, context):
    # Conexão S3
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']   
    source = {'Bucket': bucket, 'Key': key} 
    
    
    ### Declare vars 
    host_ip='sftp-server'
    host_port=22
    username='sftp_user'
    password='sftp_passwd'
    # pkey_path="lambda_kp.pem"

    # Conexão SFTP
    host = 'sftp-server'
    port = 22
    username = 'sftp_user'
    password = 'sftp_passwd'
    transport = paramiko.Transport((host, port))
    transport.connect(username=username, password=password)
    sftp = paramiko.SFTPClient.from_transport(transport)    
    
    
    ### creating RSAKey object
    # key=paramiko.RSAKey.from_private_key_file(pkey_path)
    
    ### Create ssh client 
    ssh=paramiko.SSHClient()
    # ssh=paramiko.SFTPClient()

    ### Automatically add the host to varified host file
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    ### Make a connection
    # ssh.connect(hostname=host_ip, username=username, password=password)
    # ssh.connect(hostname=host_ip, username=username, pkey=key)
    
    ### Run commands
    # stdin, stdout, stderr = ssh.exec_command('ls -al > /home/sftp/teste-lambda.txt')
    # stdin, stdout, stderr = sftp.put('ls -al > /home/sftp/teste-lambda.txt')

    # Download do arquivo S3
    try:
        s3_object = s3.get_object(source)
        # with tempfile.NamedTemporaryFile() as temp_file: 
        #     s3.download_file(bucket, key, temp_file.name)
        #     logger.info("File downloaded to lambda successfully!")
        # Upload do arquivo para SFTP
        sftp.putfo(s3_object['Body'], f'/sftp_user/{s3_object.name}', callback=None, confirm=True)    
        logger.info("File copied to the destination bucket successfully!")
        
    except paramiko.sftp.SFTPError as error:
        logger.error("There was an error with SFTP connection")
        print('Error Message: {}'.format(error))
    
    except botocore.exceptions.ClientError as error:
        logger.error("There was an error copying the file to local")
        print('Error Message: {}'.format(error))
    
    except botocore.exceptions.ParamValidationError as error:
        logger.error("Missing required parameters while calling the API.")
        print('Error Message: {}'.format(error))        
              
    
    ### Print the stdout
    # for line in stdout.read().splitlines():
    #     print(line.decode("utf-8"))
    
    ### Close the client
    ssh.close()
    # Desconexão SFTP
    sftp.close()
    transport.close()    
